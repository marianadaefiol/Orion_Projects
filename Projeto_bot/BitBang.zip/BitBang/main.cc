#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <iostream>

#include <fcntl.h>
#include <termios.h>
#include <sys/ioctl.h> //ioctl() call defenitions

// ref.: https://www.xanthium.in/Controlling-RTS-and-DTR-pins-SerialPort-in-Linux

int main(int argc, char *argv[])
{
  if(argc < 4)
  {
    printf("Número de argumentos inválido. Digite:\n");
    printf("./BitBang [porta] [pulsos] [intervalo (ms)]\n");
    return(-1);
  }
  
  int pulses = strtol(argv[2], NULL, 10);
  int delay = strtol(argv[3], NULL, 10);
  
  printf("Porta    : %s\n", argv[1]);
  printf("Pulsos   : %d\n", pulses);
  printf("Intervalo: %d ms\n", delay);
  delay = delay * 1000; // converte de ms para us

  
  int fd;
  fd = open(argv[1],O_RDWR | O_NOCTTY ); //Open Serial Port
  
  int DTR_flag;
  DTR_flag = TIOCM_DTR;
  
  ioctl(fd,TIOCMBIS,&DTR_flag);//Set DTR pin
  while(1)
  {
    usleep(delay);
    printf("Enviando %d pulsos\n", pulses);
    for(int i = 0; i < pulses; i ++)
    {
      ioctl(fd,TIOCMBIC,&DTR_flag);//Clear DTR pin
      usleep(50000);
      ioctl(fd,TIOCMBIS,&DTR_flag);//Set DTR pin
      usleep(50000);
    }
    printf("Pulsos enviados... aguarde %d segundos\n", delay);
  }
  
  close(fd);
}
